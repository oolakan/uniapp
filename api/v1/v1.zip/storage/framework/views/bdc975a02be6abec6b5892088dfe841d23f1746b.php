<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Parcel-it | Invoice</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
</head>
<body class="skin-blue">
<div class="wrapper row-offcanvas">
    <aside class="right-side">
        <section class="content invoice">
            <!-- title row -->
            <div class="row">
                <div class="col-xs-12">
                    <h2 class="page-header" style="color: #0000ff">
                        <i class="fa fa-globe"></i> Parcel-it Receipt.
                        <small class="pull-right"><?php echo e(date('Y:m:d')); ?></small>
                    </h2>
                </div><!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">

                    <table width="50%">
                        <tr><td>  From
                                <address>
                                    <strong>Parcel-it.</strong><br>
                                    795 Folsom Ave, Suite 600<br>
                                    San Francisco, CA 94107<br>
                                    Phone: +234 (0)803 496 5213<br/>
                                    Email: info@parcelit.com.ng
                                </address></td>
                            <td align="right">
                                To
                                <address>
                                    <strong><?php echo e($recipient_name); ?></strong><br>
                                    <?php echo e($recipient_email); ?><br>
                                    <?php echo e($recipient_phone_no); ?><br>
                                </address>
                            </td>
                        </tr>
                    </table>
                    <hr width="50%" align="left"/>
                </div><!-- /.col -->

                <div class="col-sm-4 invoice-col">
                    <b>Invoice #<?php echo e($invoice); ?></b><br/>
                    <br/>
                    <b>Order ID:</b> <?php echo e($track_id); ?><br/>
                    <b>Payment Status:</b> <?php echo e($parcel_delivery_status); ?><br/>
                </div><!-- /.col -->
            </div><!-- /.row -->

            <!-- Table row -->

            <div class="row">
                <div class="col-xs-12 table-responsive">
                    <hr width="50%" align="left"/>
                    <table class="table table-striped" width="50%">
                        <thead>
                        <tr>
                            <th align="left">Service</th>
                            <th align="right">Subtotal</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><?php echo e($delivery_statement); ?></td>
                            <td align="right"><?php echo e($total_delivery_cost); ?></td>
                        </tr>

                        </tbody>
                    </table>
                    <hr width="50%" align="left"/>
                </div><!-- /.col -->
            </div><!-- /.row -->

            <div class="row">
                <!-- accepted payments column -->
                <div class="col-xs-6">
                    <p class="lead">Payment Method: Card</p>
                    <hr width="50%" align="left"/>
                </div><!-- /.col -->
                <div class="col-xs-6">
                    <p class="lead">Amount Due <?php echo e(date('Y:m:d')); ?></p>
                        <table class="table" width="50%">
                            <tr>
                                <td align="left">Base Fare:</td>
                                <td align="right">N500.00</td>
                            </tr>
                            <tr>
                                <td align="left">Distance</td>
                                <td align="right"><?php echo e($delivery_distance_cost); ?></td>
                            </tr>

                            <tr>
                                <td align="left">Total:</td>
                                <td align="right"><?php echo e($total_delivery_cost); ?></td>
                            </tr>
                        </table>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </section><!-- /.content -->
    </aside><!-- /.right-side -->
</div><!-- ./wrapper -->
<!-- Bootstrap -->
</body>
</html>