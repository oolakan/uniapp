<?php
/**
 * Created by PhpStorm.
 * User: HighStrit
 * Date: 29/10/2016
 * Time: 23:47
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;

class SmsController extends Controller{
    private $sms_url;
    private $recipient_phone;
    public function __construct(){
    }
    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse|\Symfony\Component\HttpFoundation\Response
     * send sms
     */
    public function sms(Request $request)
    {
        $receiver_name      =   $request->receiver_name;
        $receiver_phone     =   $request->receiver_phone_no;
        $sender_name        =   $request->sender_name;
        $sender_phone       =   $request->sender_phone_no;
        $receiver_address   =   $request->receiver_address;
        $this->recipient_phone  =   $receiver_phone;

        $message            =   'This is to notify you that a parcel delivery will be made to you shortly at '.$receiver_address;
        $message = preg_replace('/\s/', '%20', $message);
        $this->sms_url = 'http://www.estoresms.com/smsapi.php?username=parcel-it&password=parcel2017&sender=Parcel-it&recipient=' . $this->recipient_phone . '&message=' . $message;
        $this->getContent($this->sms_url);
        return response()->json(array('message' => 'message sent successfully'));
    }
    /**
     * @param $url
     * @return mixed|string
     * Get contents from url
     */
    public function getContent($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $contents = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
            echo "\n<br />";
            $contents = '';
            return $contents;
        } else {
            curl_close($ch);
        }
        if (!is_string($contents) || !strlen($contents)) {
            echo "Failed to get contents.";
            $contents = '';
            return $contents;
        }
        return $contents;
    }

}