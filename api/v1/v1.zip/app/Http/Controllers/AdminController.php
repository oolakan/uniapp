<?php
/**
 * Created by PhpStorm.
 * User: HighStrit
 * Date: 30/10/2016
 * Time: 13:14
 */

namespace App\Http\Controllers;


use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller{
    private $status_code = 0;
    private $message = '';
    public function __construct(){

    }
    public function index(){
        $Admin = Admin::all();
        return response()->json(array('Admin' => $Admin));
    }
    /**
     * create new admin
     */
    public function createAdmin(Request $request){
        $rules = [
            'name' => 'required|max:20',
            'username' => 'required|max:20',
            'password' => 'required|max:20',
            'email' => 'required|max:20',
            'mobile' => 'required|max:20',
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            $this->status_code = 400;
            $this->message = 'Empty or bad request sent';
            return response()->json(array('message' => $this->message, 'status' => $this->status_code));
        }
        else{
            $Admin = new Admin();
            $Admin->name = $request->name;
            $Admin->username = $request->username;
            $Admin->password = $request->password;
            $Admin->email = $request->email;
            $Admin->mobile = $request->mobile;
            $Admin->save();
            $this->status_code = 201;
            $this->message = 'New Admin record created successfully';
            return response()->json(array('status' => $this->status_code, 'message' => $this->message, 'AdminRecord' => $Admin));
        }
    }
    /**
     * Update Admin
     */
    public function updateAdmin(Request $request, $id){
        $rules = ['name' => 'required|max:20',
        'username' => 'required|max:20',
        'mobile' => 'required|max:20',
        'email' => 'required|max:20'];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails()){
            $this->status_code = 400;
            $this->message = 'Empty or bad request sent';
            return response()->json(array('satus' => $this->status_code, 'message' => $this->message));
        }
        else{
            $admin = Admin::find($id);
            $admin->name = $request->input('name');
            $admin->username = $request->input('username');
            $admin->mobile = $request->input('mobile');
            $admin->save();
            $this->status_code = 200;
            $this->message = 'Admin record updated successfully';
            return response()->json(array('status' => $this->status_code, 'message' => $this->message, 'AdminRecord' => $admin));
        }
    }
    /**
     * Get Admin
     */
    public function getAdmin($id){
        $admin = Admin::find($id);
        return response()->json($admin);
    }
    /*** Delete Admin*/
    public function deleteAdmin($id){
        $admin = Admin::find($id);
        $admin->delete();
        return response()->json('AdminRecord Deleted');
    }

}