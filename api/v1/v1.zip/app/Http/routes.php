<?php
use Illuminate\Support\Facades\Request;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$app->get('/', function () use ($app) {
    return $app->version();
});
$app->get('/api/mail/credential/{name}/{email}/{username}/{password}', 'MailController@credentials');
$app->get('/api/mail/message/{username}/{email}/{msg}/{title}', 'MailController@message');


//send sms
$app->post('/api/v1/sms', 'SmsController@sms');
$app->get('/api/mail/cred/{name}/{email}/{username}/{password}/{msg}', 'MailController@cred');
$app->get('/api/mail/msg/{email}/{msg}/{title}', 'MailController@msg');

//$app->get('/api/invoice', 'MailController@invoice');


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

$app->get('/', function () {
    return view('auth.login');
});


$app->group(['prefix' => 'dashboard'], function($app){
    $app->get('/', 'DashboardController@index');
});

//users
$app->group(['prefix'  =>  'users'], function($app){
    $app->get('/', 'UserController@index');
    $app->get('/create', 'UserController@create');
    $app->post('/update/{id}', 'UserController@update');
    $app->get('/delete/{id}', 'UserController@destroy');
    $app->post('/store', 'UserController@store');
});

//Course codes and materials route
$app->group(['prefix'  =>  'course'], function($app){
    //course codes
    $app->group(['prefix'  =>  'code'], function($app) {
        $app->get('/', 'CourseCodeController@index');
        $app->get('/create', 'CourseCodeController@create');
        $app->post('/update/{id}', 'CourseCodeController@update');
        $app->get('/delete/{id}', 'CourseCodeController@destroy');
        $app->post('/store', 'CourseCodeController@store');
    });
    //course material
    $app->group(['prefix'  =>  'material'], function($app){
        $app->get('/', 'CourseMaterialController@index');
        $app->get('/create', 'CourseMaterialController@create');
        $app->post('/update/{id}', 'CourseMaterialController@update');
        $app->get('/delete/{id}', 'CourseMaterialController@destroy');
        $app->post('/store', 'CourseMaterialController@store');
    });
});

//pin
$app->group(['prefix'  =>  'pin'], function($app){
    $app->get('/', 'PinController@index');
    $app->get('/create', 'PinController@create');
    $app->get('/delete', 'PinController@destroyAll');
    $app->get('/delete/{id}', 'PinController@destroy');
    $app->post('/store', 'PinController@store');
    $app->post('/send_pin/{id}', 'PinController@sendPin');
});

