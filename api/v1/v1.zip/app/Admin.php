<?php
/**
 * Created by PhpStorm.
 * User: HighStrit
 * Date: 30/10/2016
 * Time: 13:16
 */

namespace App;


use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;

class Admin extends Model{

    use Authenticatable, Authorizable;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */

    protected $fillable = [
        'name',  'username', 'password', 'email', 'mobile'
    ];
}