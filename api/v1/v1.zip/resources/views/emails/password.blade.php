<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<div>
    <h1 style="color: #0000ff">Parcel-it</h1><hr><br>

    <div><h3>Thanks for choosing Parcel-it.</h3></div>
    <br>
    <div><b>Username: </b>{{$username}}</div><br>
    <div><b>Password: </b>{{$password}}</div><br>

</div>
</body>
</html>